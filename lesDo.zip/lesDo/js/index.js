var $small_1s=$(".small_1");
$small_1s.mouseenter(function(){
  $(this).children(":last-child").slideDown()
  // .css("display","block")
})
$small_1s.mouseleave(function(){
  $(this).children(":last-child").slideUp()
})
var $small_2s=$(".small_2");
$small_2s.mouseenter(function(){
  $(this).children(":last-child").slideDown()
})
$small_2s.mouseleave(function(){
  $(this).children(":last-child").slideUp()
})
var $bigs=$(".big");
$bigs.mouseenter(function(){
  // console.log(1111)
  // $(this).children(":last-child").css("display","block")
  $(this).children(":last-child").slideDown()
  // .css("display","block")
})
$bigs.mouseleave(function(){
  $(this).children(":last-child").slideUp()
})
