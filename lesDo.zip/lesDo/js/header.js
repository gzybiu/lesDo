$(function(){
  $.ajax({
      url:"http://127.0.0.1:5500/header.html",
      type:"get",
      success:function(res){
          //console.log(res);
          $("<link rel='stylesheet' href='css/header.css'>").appendTo("head");
          $(res).replaceAll("#header");
          // 已同意按钮
          $("#checkBtn+label").click(function(){
              $("#checkBtn+label").toggleClass("bg")    
          })
          // // 点击关闭隐藏弹出框
          $(".sclose").click(function(){
            $(".sclose").parent().css("display","none")
          })
          // 登录注册等弹窗
          var tabs=document.querySelectorAll("[data-toggle=tab]");
          console.log(tabs);
            for(var tab of tabs){
              tab.onclick=function(){
                var tab=this;
                var id=tab.getAttribute("data-target");
                id="#"+id;
                // console.log(id)
                $(id).css("display","block").siblings().css("display","none")
              } 
            } 
            // 注册验证信息
            $("#registe button").click(function(){
              var uname=$("#registe :text").val()
              var upwd=$("#registe :password").val()
              var isCheck=$("#registe :checked").val()
              console.log(uname,upwd,isCheck)
              var resUname=/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/
              var resUpwd=/^[a-zA-Z0-9]{4,8}$/
              if(isCheck==undefined){
                alert('没有勾选使用条款和隐私政策哦')
              }
              if(!resUname.test(uname)){
                alert('邮箱格式错误，请输入正确邮箱')
              }
              if(!resUpwd.test(upwd)){
                alert('密码不能少于4位多于8位，请输入正确密码')
              }
            })
            // 确认购买
            $("#vip button").click(function(){
              if($("#vip input").val()==""){
                alert('下单失败，请稍后再试')
              }else{
                location.href='https://web.iapppay.com'
              }
            })
      }
  })
})