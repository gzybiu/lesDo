$(function(){
  $.ajax({
      url:"http://127.0.0.1:5500/footer.html",
      type:"get",
      success:function(res){
          //console.log(res);
          $("<link rel='stylesheet' href='css/footer.css'>").appendTo("head");
          $(res).replaceAll("#footer");
        }
  })
  // var $weibo=$(".weibo");
    // // 设置底部的hover样式
    // var $weibo=$(".weibo");
    // var $weixin=$(".weixin");
    // var $qq=$(".qq");
    // console.log($qq)
    // console.log($qq.attr("src"))
    // $weibo.mouseenter(function(){
    //   console.log(222)
    //   $weibo.attr("src","imgs/weibo_click.png")
    // })
    // $weibo.mouseleave(function(){
    //   $weibo.attr("src","imgs/weibo.png")
    // })
    // $weixin.mouseenter(function(){
    //   $weixin.attr("src","imgs/weixin_click.png")
    // })
    // $weixin.mouseleave(function(){
    //   $weixin.attr("src","imgs/weixin.png")
    // })
    // $qq.mouseenter(function(){
    //   $qq.attr("src","imgs/qq_click.png")
    // })
    // $qq.mouseleave(function(){
    //   $qq.attr("src","imgs/qq.png")
    // })
})